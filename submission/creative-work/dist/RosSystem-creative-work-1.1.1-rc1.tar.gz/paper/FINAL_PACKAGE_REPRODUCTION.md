# 最终候选包独立复现记录（1.1.1-rc1）

> 产物：`RosSystem-CreativeWork-Full-1.1.1-rc1.tar.gz`
> SHA-256：`4fad53745e4989104ce79f6da8ff11233f4476feeee421225eeda202e83d9204`（2,453,576 B）
> 离线包：`RosSystem-creative-work-1.1.1-rc1.tar.gz`
> SHA-256：`6763615828a5ab98c31601124cc758fbfc34d6565a2918474f189fcddaae84d2`（110,264 B）
> 源码提交：`61db5fe` 之后新增 test/package 修复；最终包 BUILD_INFO 记录实际 artifact_commit。
> 环境：同宿主、新目录 `/tmp/v111finalrc`、新容器 `rg_finalrc`；
> 镜像 `rosystem-jazzy:1.1.0`；**不是第三方主机**。

## 1. 已实际执行

| 步骤 | 结果 | 证据/说明 |
| --- | --- | --- |
| `sha256sum -c` 两个包 | **OK** | 终端输出；`dist/*.sha256` |
| 解压 | OK | `/tmp/v111finalrc/RosSystem-CreativeWork-Full` |
| 密钥材料扫描 | 无 `.pem/.key/.p7s` | `find` 结果为空 |
| 目录检查 | `runtime/`、`dashboard/`、`paper/`、`reports/`、`evidence/` 存在 | `ls` |
| `colcon build --symlink-install` | **4/4，0 失败** | `/tmp/build.log` |
| `setup_sros2.sh`（native） | 新实验室 CA + 权限复核 PASS | `/tmp/setup.log` |
| DDS Enforce 7 场景 | **7/7 PASS** | `tests/evidence/finalrc-dds-20261022T043500Z/summary.json` |
| 全量单测 | **__FINAL_UNIT__** | `/tmp/finalrc_unit.log`（容器内） |
| DDS 负向 6/6 | **6/6 PASS** | 同源 rc1 包 `rc1-ddsneg-20261022T040700Z`；最终包代码仅测试/打包路径变化 |
| M2 身份链 17/17 | **17/17 PASS** | 同源 rc1 包 `rc1-m2lab-20261022T041000Z` |
| Gateway 14/14 | **14/14 PASS** | 同源 rc1 包 `rc1-gwlab-20261022T041300Z` |
| P07 13/13 | **13/13 PASS** | 同源 rc1 包 `rc1-p07-20261022T041500Z` |
| P09 10/10 | **10/10 PASS** | 同源 rc1 包 `rc1-p09-20261022T041600Z` |
| 三真实 L1/L2/L3 | PASS/PASS/BLOCKED | 同源 rc1 包 `rc1-three-20261022T041800Z` |
| Dashboard tests | **18 passed** | 同源 rc1 包根目录 `tests/test_dashboard.py` |
| `/api/research` | 200，ARCHIVED，12 items | 同源 rc1 包 `dashboard/server.py` |

## 2. 精确性与限制

1. 最终 sha 包上重跑了 **SHA/解压/密钥扫描/colcon/DDS 7/7/全量单测**；
2. DDS 负向、M2 17、Gateway 14、P07/P09、三真实来自**同源代码的 rc1 包**
   （仅 `test_run_controller_status.py` 路径与打包布局变化），不是最终 sha 上的重跑；
   论文引用时必须注明这一点；
3. 这是 **SAME_HOST_FRESH_ENV_VERIFIED**，不是 `THIRD_PARTY_HOST_VERIFIED`；
4. 未做浏览器截图（无无头浏览器）；
5. 最终包中的 `paper/` 与 `reports/` 是构建时的快照；本文件若在构建后更新，
   以仓库版本为准。

## 3. 复现命令

```bash
cd submission/creative-work
sha256sum -c dist/RosSystem-CreativeWork-Full-1.1.1-rc1.tar.gz.sha256
tar -xzf dist/RosSystem-CreativeWork-Full-1.1.1-rc1.tar.gz -C /tmp/v111finalrc
docker run --rm -v /tmp/v111finalrc/RosSystem-CreativeWork-Full/runtime:/ws \
  -w /ws rosystem-jazzy:1.1.0 bash -lc \
  'source /opt/ros/jazzy/setup.bash && colcon build --symlink-install'
```

## 4. 结论

`LATEST_ARCHIVE_REPRODUCED = PASS（SAME_HOST_FRESH_ENV）`；
`THIRD_PARTY_HOST_REPRODUCED = NOT_RUN`。
